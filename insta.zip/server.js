const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

app.post('/login', (req, res) => {
    const userId = req.body.userId;
    const password = req.body.password;

    // Log the received ID and password
    console.log('User ID:', userId);
    console.log('Password:', password);

    // Send a response to the client
    res.send('Login data received');
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
